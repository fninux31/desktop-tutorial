!/bin/sh
./rom -a firopow -o stratum+tcp://pool.woolypooly.com:3104 -u aGXimLvzqmXhC8ZQihJ7Ha2XURHPNGyRzX -p x
